from qq_group_manager.app import main

if __name__ == "__main__":
    main()

